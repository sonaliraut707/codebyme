<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Task</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body>
	<div class="container" style="margin-top:20px;">
		<div class="row">
			<div class="col-md-12">
				<h2>Add Task</h2>
				<?php if(Session::has('success')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo e(Session::get('success')); ?>

				</div>
				<?php endif; ?>
				<form method="post" action="<?php echo e(url('save-task')); ?>">
					<?php echo csrf_field(); ?>
					<div class="md-3">
						<label class="form-label">Task</label>	
						<input type="text" class="form-control" name="task" placeholder="Enter Task" value="<?php echo e(old('task')); ?>">
						<?php $__errorArgs = ['task'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="alert alert-danger" role="alert">
								<?php echo e($message); ?>

							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

						<label class="form-label">Description</label>	
						<textarea type="text" class="form-control" name="description" placeholder="Description" value="<?php echo e(old('task')); ?>">
						</textarea>
						<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="alert alert-danger" role="alert">
								<?php echo e($message); ?>

							</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

					</div><br>
					<button type="submit" class="btn btn-primary">Submit</button>					
						<a href="<?php echo e(url('task-list')); ?>" class="btn btn-danger">Back</a>
				</form>
			</div>
		</div>
	</div>			
</body>
</html><?php /**PATH /var/www/html/MyTask/resources/views/add-task.blade.php ENDPATH**/ ?>